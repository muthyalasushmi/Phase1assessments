package com.sushmi.Book;

import java.util.Scanner;

public class TestingBook {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Book title");
		String BT=sc.nextLine();
		
		System.out.println("Enter the Book price");
		int price=sc.nextInt();
		sc.nextLine();
		
		Book n=new Book();
		n.setBooktitile(BT);
		n.setBookprice(price);
		System.out.println("Book Details");
		System.out.println("Book Title :"+n.getBooktitile());
		System.out.println("Book Price :"+n.getBookprice());
	}

}
