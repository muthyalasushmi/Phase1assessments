package com.sushmi.Rectangle;

import java.util.Scanner;

public class Rectangle {

		int length; 
	    int breadth; 
	    int area; 
	   
       void ip() {
	        Scanner s = new Scanner(System.in);
	        System.out.print("Enter length of rectangle: ");
	        length = s.nextInt();
	        System.out.print("Enter breadth of rectangle: ");
	        breadth = s.nextInt();
	    }

	    void calculate() {
	        area = length * breadth;
	    }

	    void display() {
	        System.out.println("Area of Rectangle = " + area);
	    }

	    public static void main(String args[]) {
	        Rectangle obj = new Rectangle();
	        obj.ip();
	        obj.calculate();
	        obj.display();
	    }
	}

	
