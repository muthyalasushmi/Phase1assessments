package com.sushmi.Employee;

public class Employee {

	private int empid;
	private String  ename, address;
	
	public Employee (int empid, String ename, String address) {
		
		super();
		this.empid=empid;
		this.ename=ename;
		this.address=address;
	}
	
	public int getid() {
		return empid;
	}
	public void setid(int empid) {
		this.empid = empid;
	}
	public String getname() {
		return ename;
	}
	public void setname(String ename) {
		this.ename = ename;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}