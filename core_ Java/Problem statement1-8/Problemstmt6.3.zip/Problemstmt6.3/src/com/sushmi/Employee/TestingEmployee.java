package com.sushmi.Employee;

import java.util.Vector;

public class TestingEmployee {
	private static final Employee[] v = null;
	public static void main(String[] args) {
		Vector<Employee> v= addInput();
		display(v);
	}
	private static Vector<Employee> addInput() {
		
		return null;
	}
	private static void display(Vector<Employee> v) {
		
	}
	
	public static Vector<Employee> main1() {
		
		Employee e1=new Employee(11, "sushmi", "pavi");
		Employee e2=new Employee(12, "vinod", "naresh");
		Employee e3=new Employee(13, "naveen", "anu");
		Vector<Employee> v=new Vector<Employee>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
		
	}
	public static void main2(String[] args) {
		
		for (Employee e :v) {
			System.out.println(e.getid()+"\t"+e.getname()+"\t"+e.getAddress());
			
		}
	}
}
