package com.sushmi.StudentArrayList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class StudentNameAarryList {
	public static void main(String[] args) {
		ArrayList<String> a1=new ArrayList<String>();
		
		int n;
		Scanner abc=new Scanner(System.in);
		System.out.println("Enter the number of students :");
		n=abc.nextInt();
		System.out.println("Enter the student names :");
		
		for (int i=0; i<n; i++) {
			
			a1.add(abc.next());
			
		}
		System.out.println("student list :");
		
		for (String string : a1) {
			
			System.out.println("Enter the name of searchable student :");
			String st=abc.next();
			int position=Collections.binarySearch(a1,st);
			System.out.println("position of"+st+"is :"+position);
			
		}
	}

}
